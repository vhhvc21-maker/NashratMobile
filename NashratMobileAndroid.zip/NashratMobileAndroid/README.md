# نشرة الموبايلات — Android Studio

مشروع Android Studio جاهز لتحويل النسخة الحالية إلى APK.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر Build > Build APK(s).
4. ستجد APK داخل `app/build/outputs/apk/debug/`.

التطبيق يستخدم WebView لعرض واجهة النسخة الأولى، والبيانات التجريبية محفوظة محلياً.
رمز لوحة الإدارة التجريبية: 1234.
